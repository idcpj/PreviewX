Archive preview fixture
