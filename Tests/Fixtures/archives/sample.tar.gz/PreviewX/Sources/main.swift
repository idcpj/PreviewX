print("archive")
